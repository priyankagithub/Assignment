angular.module('wmApp.widget.controllers',[]);
angular.module('wmApp.widget.directives',[]);
angular.module('wmApp.widget.services',[]);
angular.module('wmApp.widget.routes',[]);