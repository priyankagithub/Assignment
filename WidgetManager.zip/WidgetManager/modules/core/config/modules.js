angular.module('wmApp.core.filters',[]);
angular.module('wmApp.core.services',[]);
