/**
 * @ngdoc filter
 * @name pascalprecht.translate.filter:translate
 * @requires $parse
 * @requires pascalprecht.translate.$translate
 * @function
 *
 * @description
 * Uses "$translate" service to translate contents. Accepts interpolate parameters
 * to pass dynamized values though translation.
 *
 * @param {string} translationId A translation id to be translated.
 * @param {*=} interpolateParams Optional object literal (as hash or string) to pass values into translation.
 *
 * @returns {string} Translated text.
 *
 * @example
 <example module="ngView">
 <file name="index.html">
     <div ng-controller="TranslateCtrl">
         <pre>{{ 'TRANSLATION_ID' | trans }}</pre>
         <pre>{{ translationId | trans }}</pre>
         <pre>{{ 'WITH_VALUES' | trans:'{value: 5}' }}</pre>
         <pre>{{ 'WITH_VALUES' | trans:values }}</pre>
     </div>
 </file>
 <file name="script.js">
     angular.module('ngView', ['pascalprecht.translate'])
     .config(function ($translateProvider) {
        $translateProvider.translations('en', {
          'TRANSLATION_ID': 'Hello there!',
          'WITH_VALUES': 'The following value is dynamic: {{value}}'
        });
        $translateProvider.preferredLanguage('en');
     });
     angular.module('ngView').controller('TranslateCtrl', function ($scope) {
        $scope.translationId = 'TRANSLATION_ID';
        $scope.values = {
          value: 78
        };
     });
   </file>
 </example>
 */
angular.module('wmApp.core.filters').filter('trans', ['$parse', '$translate', function ($parse, $translate) {
    var translateFilter = function (translationId, interpolateParams, interpolation) {
        if (!angular.isObject(interpolateParams)) {
            interpolateParams = $parse(interpolateParams)(this);
        }
        return $translate.instant(translationId, interpolateParams, interpolation);
    };

    // Since AngularJS 1.3, filters which are not stateless (depending at the scope)
    // have to explicit define this behavior.
    translateFilter.$stateful = true;
    return translateFilter;
}]);